<?php $__env->startSection('title','My Order'); ?>

<?php $__env->startSection('body'); ?>

    <!--Breadcrumb -->
    <div class = "container">
        <div class = "row">
            <div class = "col-lg-12">
                <div class = "breadcrumb-text">
                    <a href = "/">Home</a>
                    <span>Check out</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Main -->
<section class="shopping-cart spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="cart-table">
                    <table>
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>IMAGE</th>
                            <th>PRODUCT</th>
                            <th>SIZE</th>
                            <th>COLOR</th>
                            <th>PRICE</th>
                            <th>QTY</th>
                            <th>TOTAL</th>
                            <th>STATUS</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($order->id == $orderDetail->order_id): ?>

                                    <tr>
                                        <td class="first-row"><?php echo e($orderDetail->order_id); ?></td>
                                        <td class="cart-pic first-row"><img style="height: 100px;"
                                        src="front/img/products/<?php echo e($orderDetail->product_image); ?>" alt=""></td>
                                        <td class="cart-title first-row text-center">
                                            <h5><?php echo e($orderDetail->product_name); ?>

                                            </h5>
                                        </td>
                                        <td class="cart-title first-row text-center">
                                            <?php echo e($orderDetail->product_size); ?>

                                        </td>
                                        <td class="cart-title first-row text-center">
                                            <?php echo e($orderDetail->product_color); ?>

                                        </td>
                                        <td class="cart-title first-row text-center">
                                            <?php echo e($orderDetail->amount); ?>

                                        </td>
                                        <td class="cart-title first-row text-center">
                                            <?php echo e($orderDetail->qty); ?>

                                        </td>
                                        <td class="total-price first-row text-center">$<?php echo e($orderDetail->total); ?></td>
                                        <td class="total-price first-row text-center"><?php echo e(\App\Utilities\Constant::$order_status[$order->status]); ?></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\katmi\Documents\Project\MICO_SHOP\resources\views/front/account/my-order/index.blade.php ENDPATH**/ ?>