<?php $__env->startSection('title','Checkout'); ?>

<?php $__env->startSection('body'); ?>
                                                    <!-- Body -->
<!--Breadcrumb -->
<div class = "container">
    <div class = "row">
        <div class = "col-lg-12">
            <div class = "breadcrumb-text">
                <a href = "/">Home</a>
                <span>Check out</span>
            </div>
        </div>
    </div>
</div>

<!-- Main -->

<section class = "checkout">
    <div class = "container">
        <div class = "row">
            <div class = "col-lg-6 main-info order-2 order-lg-1">
                <h2 class="mb-5">Delivery Information</h2>

                <form method="post" action="">
                    <?php echo csrf_field(); ?>
                <div class = "row">
                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id ?? ''); ?>">
                    <div class = "col-lg-12 input-all">
                        <label class="font-weight-bold">First Name*</label>
                        <div class = "input-form">
                            <input type="text" placeholder="First Name" name="name" value="<?php echo e(Auth::user()->name ?? ''); ?>">
                        </div>
                    </div>






                </div>
                    <div class = "row">
                        <div class = "col-lg-6 input-all">
                            <label class="font-weight-bold">Email*</label>
                            <div class = "input-form">
                                <input type="text" placeholder="Email" name="email" value="<?php echo e(Auth::user()->email ?? ''); ?>">
                            </div>
                        </div>
                        <div class="col-lg-6 input-all">
                            <label class="font-weight-bold">Phone*</label>
                            <div class = "input-form">
                                <input type="text" placeholder="Phone*" name="phone" value="<?php echo e(Auth::user()->phone ?? ''); ?>">
                            </div>
                        </div>
                    </div>
                <div class = "row">
                    <div class="col-lg-12 input-all">
                        <label class="font-weight-bold">Company Name</label>
                        <div class = "input-form">
                            <input type="text" placeholder="Company Name" name="company_name" value="<?php echo e(Auth::user()->company_name ?? ''); ?>">
                        </div>
                    </div>
                </div>
                <div class = "row">
                    <div class = "col-lg-6 input-all">
                        <label class="font-weight-bold">Country*</label>
                        <div class = "input-form">
                            <input type="text" placeholder="Country" name="country" value="<?php echo e(Auth::user()->country ?? ''); ?>">
                        </div>
                    </div>

                    <div class = "col-lg-6 input-all">
                        <label class="font-weight-bold">Town/City*</label>
                        <div class = "input-form">
                            <input type="text" placeholder="Town/City" name="town_city" value="<?php echo e(Auth::user()->town_city ?? ''); ?>">
                        </div>
                    </div>
                </div>
                <div class = "row">
                    <div class="col-lg-12 input-all">
                        <label class="font-weight-bold">Street Address*</label>
                        <div class = "input-form">
                            <input type="text" placeholder="Street Address" name="street_address" value="<?php echo e(Auth::user()->street_address ?? ''); ?>">
                        </div>
                    </div>
                </div>
                <div class = "row">
                    <div class = "col-lg-12 input-all">
                        <label class="font-weight-bold">Postcode/Zip</label>
                        <div class = "input-form">
                            <input type="text" placeholder="Postcode/Zip" name="postcode_zip" value="<?php echo e(Auth::user()->postcode_zip ?? ''); ?>">
                        </div>
                    </div>
                </div>

                <h6 class="mt-3">Payment method &nbsp;&nbsp;<i class="fa fa-lock"></i></h6>
                <div class = "method" id = "method1">
                    <input type="radio" name="payment_type" id = "cash" value = "COD">
                    <label class="radio-container cashLabel"> Cash on delivery (COD)</label>
                </div>
                <div class = "method" id = "method2">
                    <input type="radio" name="payment_type" id = "vnpay" value = "VNPAY">
                    <label class="radio-container"> VN PAY</label>
                </div>

                <div class = "input-checkbox">
                    <input type = "checkbox" id = "cc13">
                    <p>I agree to <a href = "terms.html">Terms and Conditions</a>.
                    See <a href = "terms.html">Privacy and Cookie Policy</a> for information on how we use the information
                    you provide to us.</p>
                </div>

                <div class = " row buttons">
                    <div class = "col-lg-6">
                        <button class = "backtocart"><a href = "./cart">BACK TO CART</a></button>
                    </div>
                    <div class = "col-lg-6">
                        <button class = "placeorder" type = "submit"><a>PLACE MY ORDER</a></button>
                    </div>
                </div>
                </form>
            </div>

            <div class = "col-lg-6 main-info order-1 order-lg-2">
                <h2 class="mb-5"> Your Order</h2>

                <div class="cart-table">
                    <table>
                        <thead>
                            <tr>
                            <th>PRODUCT NAME</th>
                            <th>SIZE</th>
                            <th>COLOR</th>
                            <th>PRICE</th>
                            <th>QTY</th>
                            <th>TOTAL</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="first-row">
                                    <p><?php echo e($item->product_name); ?></p>
                                </td>
                                <td class="first-row">
                                    <p><?php echo e($item->product_size); ?></p>
                                </td>
                                <td class="first-row">
                                    <p><?php echo e($item->product_color); ?></p>
                                </td>
                                <td class="p-price first-row">
                                    <p>$<?php echo e(number_format($item->product_price,2)); ?></p>
                                </td>
                                <td class="p-price first-row">
                                    <div class="d-flex align-items-center justify-content-center">
                                        <p> <?php echo e($item->qty); ?></p>
                                    </div>
                                </td>
                                <td class="total-price first-row">
                                    <p>$<?php echo e(number_format($item->total,2)); ?></p>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td class="first-row">
                                    <p>Subtotal</p>
                                </td>
                                <td class="first-row">
                                    <p>$<?php echo e(number_format($subtotal,2)); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td class="first-row">
                                    <p>Total</p>
                                </td>
                                <td class="first-row">
                                    <p>$<?php echo e(number_format($total,2)); ?></p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Vision -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\katmi\Documents\Project\MICO_SHOP\resources\views/front/checkout/index.blade.php ENDPATH**/ ?>