<?php $__env->startSection('title','Blog'); ?>

<?php $__env->startSection('body'); ?>
<!--Breadcrumb -->
<div class = "container">
    <div class = "rowr">
        <div class = "col-lg-12">
            <div class = "breadcrumb-text">
                <a href = "index.html">Home</a>
                <span>Blogs</span>
            </div>
        </div>
    </div>
</div>

<!-- Banner Header -->
<div id = "banner" style = "background-image: url(img/blog/bannerall.png)">
    <div id = "banner-text">
        <h2>Our Blog</h2>
    </div>
</div>


<!-- Body -->
<div class = "container">
    <section class="blog">
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class = "row blog-title">
            <div class = "col-lg-5 blog-image">
                <img src="front/img/blog/<?php echo e($blog->image); ?>" style="height: 300px; width: 180px;">
            </div>
            <div class = "col-lg-7">
                <div>
                    <h6><?php echo e($blog->category); ?></h6>
                </div>
                <div>
                    <a href = "blogdetail/<?php echo e($blog->id); ?>"><h3><?php echo e($blog->title); ?></h3></a>
                </div>
                <div>
                    <p><?php echo e($blog->subtitle); ?></p>
                </div>
                <div>
                    <h6 class = "date"><?php echo e($blog->created_at); ?></h6>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>



</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\katmi\Documents\Project\MICO_SHOP\resources\views/front/blog.blade.php ENDPATH**/ ?>