<?php $__env->startSection('title','Result'); ?>

<?php $__env->startSection('body'); ?>
                                                    <!-- Body -->
<!--Breadcrumb -->
<div class = "container">
    <div class = "row">
        <div class = "col-lg-12">
            <div class = "breadcrumb-text">
                <a href = "/">Home</a>
                <a href = "/checkout">Check out</a>
                <span>Result</span>
            </div>
        </div>
    </div>
</div>

<!-- Main -->

<section class = "checkout">
    <div class = "container">
        <div class = "row">
            <div class = "col-lg-12">
                <p><?php echo e($notification); ?></p>
                <a href="./" class="primary-btn mt-5"> Continue shopping</a>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\katmi\Documents\Project\MICO_SHOP\resources\views/front/checkout/result.blade.php ENDPATH**/ ?>