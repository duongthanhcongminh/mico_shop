

<?php if(session('notification')): ?>
    <div class="alert alert-warning" role="alert">
        <?php echo e(session('notification')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\Users\katmi\Documents\Project\MICO_SHOP\resources\views/admin/components/notification.blade.php ENDPATH**/ ?>