<?php $__env->startSection('title','Blog'); ?>

<?php $__env->startSection('body'); ?>

    <!--Breadcrumb -->
<div class = "container">
    <div class = "row">
        <div class = "col-lg-12">
            <div class = "breadcrumb-text">
                <a href = "index.html">Home</a>
                <span>Blogs</span>

            </div>
        </div>
    </div>
</div>

<!-- Banner Header -->
<div id = "banner" style = "background-image: url(img/blog/banner-getinsp.jpg)">
    <div id = "banner-text">
        <h2>Get Inspired</h2>
    </div>
</div>

<!-- Body -->
    <div class = "container">
        <section class="blog1">
            <div id="tittle1">
                <h6><?php echo e($blog->category); ?></h6>
                <a href = "blogdetail02.html"><h3><?php echo e($blog->title); ?> </h3></a>
                <p><?php echo e($blog->subtitle); ?></p>
                <h6 class = "date"><?php echo e($blog->created_at); ?></h6>
            </div>
            <div class = "row content1">
                <div class = "col-lg-12">
                    <p>
                        <?php echo e($blog->content); ?>

                    </p>

                </div>
            </div>
        </section>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\katmi\Documents\Project\MICO_SHOP\resources\views/front/blogdetail.blade.php ENDPATH**/ ?>