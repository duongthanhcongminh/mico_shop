<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('body'); ?>



<!-- Back to Top - Chat Code -->

<div class = "container">
    <button onclick="topFunction()" id="myBtn" title="Go to top"><i class = "fa fa-chevron-up"></i></button>
</div>
<script>
    //Get the button
    var mybutton = document.getElementById("myBtn");

    window.onscroll = function() {scrollFunction(); myFunction();};

    var navbar = document.querySelector(".nav-bar-container");

    // Get the offset position of the navbar

    // Add the sticky class to the navbar when you reach its scroll position. Remove "sticky" when you leave the scroll position
    function myFunction() {
        if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
            navbar.classList.add("sticky")
        } else {
            navbar.classList.remove("sticky");
        }
    }
    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            mybutton.style.display = "block";
        } else {
            mybutton.style.display = "none";
        }
    }

    // When the user clicks on the button, scroll to the top of the document
    function topFunction() {
        window.scrollTo({top: 0, behavior: 'smooth'});
    }
</script>

<!-- Messenger Plugin chat Code -->
<div id="fb-root"></div>

<!-- Plugin chat code -->
<div id="fb-customer-chat" class="fb-customerchat">
</div>

<script>
    var chatbox = document.getElementById('fb-customer-chat');
    chatbox.setAttribute("page_id", "113055687951669");
    chatbox.setAttribute("attribution", "biz_inbox");
</script>

<!-- Your SDK code -->
<script>
    window.fbAsyncInit = function() {
        FB.init({
            xfbml            : true,
            version          : 'v12.0'
        });
    };

    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
</script>
<!-- Body -->
<div class = "notification-toast animate__animated"></div>
<!-- Hero Section -->
<section class = "hero-section">
    <div class = "hero-items owl-carousel">
        <div class = "single-hero-items set-bg" data-setbg = "front/img/hero-1.jpg">
            <div class = "container">
                <div class = "row">
                    <div class = "col-lg-5">
                        <h4>Girl's Collection</h4>
                        <h1>NEW ARRIVALS</h1>
                        <p></p>
                        <a href = "#" class = "primary-btn">Shop Now</a>
                    </div>
                </div>
            </div>
        </div>
        <div class = "single-hero-items set-bg" data-setbg = "front/img/hero-2.jpg">
            <div class = "container">
                <div class = "row">
                    <div class = "col-lg-5">
                        <h4>Unisex Collection</h4>
                        <h1>NEW ARRIVALS</h1>
                        <p>

                        </p>
                        <a href = "#" class = "primary-btn">Shop Now</a>
                    </div>
                </div>
            </div>
        </div>
        <div class = "single-hero-items set-bg" data-setbg = "front/img/hero-3.jpg">
            <div class = "container">
                <div class = "row">
                    <div class = "col-lg-5">
                        <h4>Boy's Collection</h4>
                        <h1>NEW ARRIVALS</h1>
                        <p>

                        </p>
                        <a href = "#" class = "primary-btn">Shop Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


































































<!-- Men's  -->
<section class = "men-banner spad mt-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3">
                <div class="product-large set-bg" data-setbg="front/img/man-large.jpg">
                    <h2>Boy's</h2>
                    <a href="#">Discover More</a>
                </div>
            </div>
            <div class="col-lg-8 offset-lg-1">
                <div class = "product-slider owl-carousel d-flex justify-content-center align-items-center">
                    <?php $__currentLoopData = $featuredProducts['boy']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('front.components.product-item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Deal of the Week -->
<section class = "deal-of-week set-bg spad" data-setbg = "front/img/time-bg.png">
    <div class = "col-lg-6 text-center">
        <div class = "section-title">
            <h2>Deal Of The Week</h2>
            <p ></p>
            <div class = "product-price">
                $114.50
                <span>$229.00</span>
            </div>
        </div>
        <div class = "countdown-timer" id = "countdown">
            <div class = "cd-item">
                <span>12</span>
                <p>Days</p>
            </div>
            <div class = "cd-item">
                <span>12</span>
                <p>Hrs</p>
            </div>
            <div class = "cd-item">
                <span>48</span>
                <p>Mins</p>
            </div>
            <div class = "cd-item">
                <span>52</span>
                <p>Secs</p>
            </div>
        </div>
        <a href = "#" class = "primary-btn">Shop Now</a>
    </div>

</section>

<!-- Woman -->
<section class = "men-banner spad mt-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3">
                <div class="product-large set-bg" data-setbg="front/img/women-large.jpg">
                    <h2>Girl's</h2>
                    <a href="#">Discover More</a>
                </div>
            </div>
            <div class="col-lg-8 offset-lg-1">
                <div class = "product-slider owl-carousel d-flex justify-content-center align-items-center">
                    <?php $__currentLoopData = $featuredProducts['girl']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('front.components.product-item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="deal-of-week spad">
    <img src="front/img/hero-2.jpg">
</div>
<!-- Kid -->
<section class = "men-banner spad mt-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3">
                <div class="product-large set-bg" data-setbg="front/img/unisex-large.jpg">
                    <h2>Unisex</h2>
                    <a href="#">Discover More</a>
                </div>
            </div>
            <div class="col-lg-8 offset-lg-1">
                <div class = "product-slider owl-carousel d-flex justify-content-center align-items-center">
                    <?php $__currentLoopData = $featuredProducts['unisex']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('front.components.product-item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Shop by Brand -->









































<!-- Instagram -->
<div class = "instagram-photo">
    <div class = "insta-item set-bg" data-setbg = "front/img/insta1.jpg">
        <div class = "inside-text">
            <i class = "fa fa-instagram">
                <p><a href = "#">Instagram</a></p>
            </i>
        </div>
    </div>
    <div class = "insta-item set-bg" data-setbg = "front/img/insta2.jpg">
        <div class = "inside-text">
            <i class = "fa fa-instagram">
                <p><a href = "#">Instagram</a></p>
            </i>
        </div>
    </div>
    <div class = "insta-item set-bg" data-setbg = "front/img/insta3.jpg">
        <div class = "inside-text">
            <i class = "fa fa-instagram">
                <p><a href = "#">Instagram</a></p>
            </i>
        </div>
    </div>
    <div class = "insta-item set-bg" data-setbg = "front/img/insta4.jpg">
        <div class = "inside-text">
            <i class = "fa fa-instagram">
                <p><a href = "#">Instagram</a></p>
            </i>
        </div>
    </div>
</div>

<!-- Latest Blog Section -->
<section class = "latest-blog spad">
    <div class = "container">
        <div class = "row">
            <div class = "col-lg-12">
                <div class = "section-title">
                    <h2>Latest Blog</h2>
                </div>
            </div>
        </div>
        <div class = "row">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class = "col-lg-4 col-md-6" data-aos="fade-up"
                     data-aos-easing="ease-in-sine">
                    <div class = "single-latest-blog">
                        <img src = "front/img/blog/<?php echo e($blog->image); ?>">
                        <div class = "latest-text">
                            <div class = "tag-list">
                                <div class = "tag-item">
                                    <i class="fa fa-calendar-0"></i>
                                    <?php echo e(date('M d, Y', strtotime($blog->created_at))); ?>

                                </div>
                            </div>
                            <a href = "blogdetail/<?php echo e($blog->id); ?>">
                                <h4><?php echo e($blog->title); ?></h4>
                            </a>
                            <p><?php echo e($blog->subtitle); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!-- Recent Uploads -->
<div class = "recent-upload">
    <div class = "container">
        <div class = "row">
            <div class = "col-lg-12">
                <div class = "section-title">
                    <h2>Recent Uploads</h2>
                </div>
            </div>
        </div>
        <div class = "row">
            <div class="owl-carousel video-items owl-theme">
                <div class="item-video" data-merge="2"><a class="owl-video" href="https://www.youtube.com/watch?v=3ItMs3k_bwY"></a></div>
                <div class="item-video" data-merge="2"><a class="owl-video" href="https://www.youtube.com/watch?v=q6iLmccaNV0"></a></div>
                <div class="item-video" data-merge="2"><a class="owl-video" href="https://www.youtube.com/watch?v=kWQZcTljiak"></a></div>
                <div class="item-video" data-merge="2"><a class="owl-video" href="https://www.youtube.com/watch?v=hoKDrFyQDy0"></a></div>
                <div class="item-video" data-merge="2"><a class="owl-video" href="https://www.youtube.com/watch?v=5fzrbjvb2Mg"></a></div>
                <div class="item-video" data-merge="2"><a class="owl-video" href="https://www.youtube.com/watch?v=yuLMna0a6GY"></a></div>
                <div class="item-video" data-merge="2"><a class="owl-video" href="https://www.youtube.com/watch?v=DsZhTIwJV5E"></a></div>
                <div class="item-video" data-merge="2"><a class="owl-video" href="https://www.youtube.com/watch?v=xZ2tCTuJI5E"></a></div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\katmi\Documents\Project\MICO_SHOP\resources\views/front/index.blade.php ENDPATH**/ ?>