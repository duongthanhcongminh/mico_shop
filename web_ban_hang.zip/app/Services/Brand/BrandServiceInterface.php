<?php

namespace App\Services\Brand;

use App\Services\ServiceInterface;

interface BrandServiceInterface extends ServiceInterface
{

}
