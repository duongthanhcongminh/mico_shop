<?php

namespace App\Repositories\ProductComment;

use App\Repositories\RepositoryInterface;

interface ProductCommentRepositoryInterface extends RepositoryInterface
{

}
